import { ColorPickerConfig } from "@tempi/core-editor";
import React from "react";

export const Setting = () => {
  return (
    <>
      <ColorPickerConfig
        propKey="textColor"
        formItemProps={{ label: "Màu chữ" }}
      />
      <ColorPickerConfig
        propKey="boldColor"
        formItemProps={{ label: "Màu chữ in đậm" }}
      />
      <ColorPickerConfig
        propKey="buttonColor"
        formItemProps={{ label: "Màu nút" }}
      />
      <ColorPickerConfig
        propKey="tableBorderColor"
        formItemProps={{ label: "Màu viền bảng" }}
      />
      <ColorPickerConfig
        propKey="buttonTextColor"
        formItemProps={{ label: "Màu chữ nút" }}
      />
    </>
  );
};
