// vite.config.js

import { defineConfig } from "vite";
import federation from "@originjs/vite-plugin-federation";
import { fileURLToPath } from "url";
import path from "path";
// get the current parent folder of vite.config
const parentFolder = path.dirname(fileURLToPath(import.meta.url));

export default defineConfig({
  plugins: [
    federation({
      name: "customElement",
      filename: "customElement.js",
      exposes: {
        "./selector": "./selector",
        "./ui": "./ui",
      },
      shared: {
        react: { generate: false, import: false },
        "react-frame-component": { generate: false, import: false },
        "@tempi/core-editor": { generate: false, import: false },
      },
    }),
  ],
  build: {
    modulePreload: false,
    target: "esnext",
    minify: false,
    cssCodeSplit: false,
    rollupOptions: {
      input: {
        main: `${parentFolder}/index.ts`,
      },
    },
  },
});
