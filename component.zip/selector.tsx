import { withSelector } from "@tempi/core-editor";
import { DEFAULT_EXAM_SCORE } from "./constants";
import { QuickSetting } from "./quick-setting";
import { Setting } from "./setting";
import { CustomElement } from "./ui";

export const CustomElementEditor = withSelector(CustomElement, {
  displayName: "Custom element 2 2 22 ",
  tag: CustomElement?.displayName?.toLowerCase() || "Custom element",
  quickSetting: QuickSetting,
  customAttributes: Setting,
  props: DEFAULT_EXAM_SCORE,
  rules: {
    canDrop: () => true,
  },
});

export default CustomElementEditor;
