import React from "react";

export const CustomElement: React.FC = () => {
  return <>Custom element</>;
};

CustomElement.displayName = "CustomElement";

export default CustomElement;
