import React from "react";
import { CustomElement } from "./ui";

export const CustomElementTest: React.FC = () => {
  return <CustomElement />;
};

CustomElement.displayName = "CustomElement";
