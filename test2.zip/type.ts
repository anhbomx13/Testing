export interface CustomElementInterface {
  textColor?: string;
  boldColor?: string;
  buttonColor?: string;
  tableBorderColor?: string;
  buttonTextColor?: string;
}
