// vite.config.js

import { defineConfig } from "vite";
import federation from "@originjs/vite-plugin-federation";

export default defineConfig({
  plugins: [
    federation({
      name: "customElement",
      filename: "customElement.js",
      exposes: {
        "./selector": "./selector",
        "./ui": "./ui",
      },
      shared: {
        react: { generate: false, import: false },
        "react-frame-component": { generate: false, import: false },
        "@tempi/core-editor": { generate: false, import: false },
      },
    }),
  ],
  build: {
    modulePreload: false,
    target: "esnext",
    minify: false,
    cssCodeSplit: false,
  },
});
