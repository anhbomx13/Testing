import { CustomElementInterface } from "./type";

export const DEFAULT_EXAM_SCORE: CustomElementInterface = {
  textColor: "#000000",
  boldColor: "#FF0000",
  buttonColor: "#7367F0",
  tableBorderColor: "#000000",
  buttonTextColor: "#FFFFFF",
};
